
<template>
    <div class="col-md-12">
        <img style="width:100%" class="ing-responsive" src="/static/assets/images/Under-Construction.png">
    </div>
</template>
