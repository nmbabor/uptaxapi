<template>
 
  <router-view :key="$route.fullPath"></router-view>
         
</template>



